import java.util.Random;

public class BinaryMatrix {
    private int[][] matrix;
    private int size;

    public static void main(String[] args) {

        BinaryMatrix matrix = new BinaryMatrix();
        matrix.setSize(5);
        matrix.setMatrix();
        int rowIndex = matrix.getRowWithMaxOnes();
        int colIndex = matrix.getColWithMaxOnes();
        matrix.displayMatrix();
        System.out.println("The largest row index: " + rowIndex);
        System.out.println("The Largest col index: " + colIndex);
    }

    public void setSize(int size){
        this.size = size;
    }

    public int getRowWithMaxOnes() {
        int max = -1;
        int rowIndex = 0;
        for (int i = 0; i < size; i++){
            int count = 0;
            count = getNoOfOnesInRow(i);
            if (count > max){
                max = count;
                rowIndex = i;
            }
        }
        return rowIndex;
    }

    public int getColWithMaxOnes() {
        int max = -1;
        int colIndex = 0;
        for (int i = 0; i < size; i++){
            int count = 0;
            count = getNoOfOnesInCol(i);
            if (count > max){
                max = count;
                colIndex = i;
            }
        }
        return colIndex;
    }

    public int getNoOfOnesInRow(int rowIndex) {
        int count = 0;
        if (rowIndex > 0 && rowIndex < size){
            for (int val:matrix[rowIndex]){
                if (val == 1){
                    count++;
                }
            }
        }
        return count;
    }

    public int getNoOfOnesInCol(int colIndex) {
        int count = 0;
        if (colIndex > 0 && colIndex < size){
            for (int i = 0; i < size; i++){
                int val = matrix[i][colIndex];
                if (val == 1){
                    count++;
                }
            }
        }
        return count;
    }

    public void setMatrix() {
        matrix = new int[size][size];
        for (int i=0; i<size; i++){
            for (int j=0; j<size; j++){
                Random rand;
                rand = new Random();
                int elem = rand.nextInt(2);
                matrix[i][j] = elem;
            }
        }
    }

    public void displayMatrix() {
        for (int i=0; i<size; i++){
            for (int j=0; j<size; j++){
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println("");
        }
    }
}
