import java.util.Random;
import java.util.Scanner;

public class PickFourCardsGame {
    private String[] cardName;
    public static void main(String[] args) {
        PickFourCardsGame game = new PickFourCardsGame();
        game.play();
    }

    public void play() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Choose");
            System.out.println("1. show number of tries needed to get sum 24");
            System.out.println("2. exit");
            int option = in.nextInt();
            int count = 0;
            if (option == 1) {
                int sum = 0;
                do {
                    count++;
                    int[] cards = pickFourCards();
                    sum = getSumOfCards(cards);
                }while (sum != 24);
                System.out.println(count + " tries needed to get sum of 24");
            } else {
                System.out.println("goodbye");
                break;
            }
        }
    }

    public int getSumOfCards(int[] cards) {
        int sum = 0;
        for (int card:cards){
            sum += card;
        }
        return sum;
    }

    public int[] pickFourCards() {
        int[] pickedCards = new int[4];
        Random rand = new Random();
        for (int i = 0; i < 4; i++){
            pickedCards[i] = rand.nextInt(13) + 1;
        }
        return pickedCards;
    }
}
