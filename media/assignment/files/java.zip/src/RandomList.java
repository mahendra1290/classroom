import java.util.Random;

public class RandomList {
    public static void main(String[] args) {
        int[] list = {9, 3, 2, 0, 1};
        int a = getRandom(list);
        System.out.println("rand from list is " + a);
    }

    public static int getRandom(int[] list){
        int len = list.length;
        Random rand = new Random();
        int index = rand.nextInt(len);
        return list[index];
    }
}
