import java.util.Scanner;

public class TelephoneNumber {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String number = in.nextLine();
        extract(number);
    }

    public static void extract(String phoneNumber) {
        String[] tokens = phoneNumber.split("[()-]");
        System.out.println("country code: " + tokens[1]);
        System.out.println("phone number: " + tokens[2] + tokens[3]);
    }
}
